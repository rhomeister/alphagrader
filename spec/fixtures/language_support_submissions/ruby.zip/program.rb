#!/usr/bin/ruby

a = gets.to_i
b = gets.to_i

puts a + b
