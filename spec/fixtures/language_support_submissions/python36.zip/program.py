#!/usr/bin/python
import fileinput


def get_sum(a: int, b: int) -> int:
    return a + b


if __name__ == '__main__':
    a, b = [int(x) for x in fileinput.input()]
    result = get_sum(a, b)
    formatted_python36_string = f'{a} + {b} = {result}'
    print(result)
