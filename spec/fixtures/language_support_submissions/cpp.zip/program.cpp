#include <string>
#include <vector>
#include <iostream>

int main(int argc, char* argv[]) {
  int a, b;

  std::cin >> a;
  std::cin >> b;

  std::cout << a + b;

  return 0;
}
