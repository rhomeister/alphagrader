#!/usr/bin/env ruby
# frozen_string_literal: true

$stdin.readlines.each do |line|
  puts line.split(' ').map(&:to_i).inject(:+)
end
